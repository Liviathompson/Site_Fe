<img width="1305" height="637" alt="image" src="https://github.com/user-attachments/assets/38ecd580-a44e-47dc-b61c-73ddade63527" />
